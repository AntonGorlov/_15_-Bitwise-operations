//
//  AppDelegate.h
//  Bitwise operations (Lesson 15)
//
//  Created by Anton Gorlov on 17.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

