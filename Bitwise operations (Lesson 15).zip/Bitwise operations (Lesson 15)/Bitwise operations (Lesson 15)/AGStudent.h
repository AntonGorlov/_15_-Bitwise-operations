//
//  AGStudent.h
//  Bitwise operations (Lesson 15)
//
//  Created by Anton Gorlov on 17.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{
    AGStudentSubjectTypeBiology=1<<0, // называем  enum названием класса,потом смысловая нагрузка и сам тип
    AGStudentSubjectTypeMath=1<<1,
    AGStudentSubjectTypeDeveloping=1<<2,
    AGStudentSubjectTypePhysics=1<<3,
    AGStudentSubjectTypePhycology=1<<4,
    AGStudentSubjectTypeEngineering=1<<5,
    AGStudentSubjectTypeArt=1<<6
    
    } AGStudentSubjectType; //называем названием класса




@interface AGStudent : NSObject
@property (assign,nonatomic) AGStudentSubjectType subjectType;
/*
@property (strong,nonatomic) NSString* name;
@property(assign,nonatomic) BOOL studiesBiology;
@property(assign,nonatomic) BOOL studiesMath;
@property(assign,nonatomic) BOOL studiesDeveloping;
@property(assign,nonatomic) BOOL studiesPhysics;
@property(assign,nonatomic) BOOL studiesPhycology;
@property(assign,nonatomic) BOOL studiesEngineering;
@property(assign,nonatomic) BOOL studiesArt;
*/
@end
