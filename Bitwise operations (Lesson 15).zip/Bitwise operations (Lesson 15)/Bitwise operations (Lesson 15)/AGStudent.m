//
//  AGStudent.m
//  Bitwise operations (Lesson 15)
//
//  Created by Anton Gorlov on 17.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent

-(NSString*) answerByType: (AGStudentSubjectType) type{ //соз метод для того,чтобы код был более читабельным
    return  self.subjectType & type ? @"Yes" :@"No";
}
-(NSString*) description {
    return [NSString stringWithFormat:@"Student studies:\n"
            "Student name's Eppe \n"
            "biology=%@ \n"
            "Math=%@ \n"
            "Developing=%@ \n"
            "Physics=%@ \n"
            "Phycology=%@ \n"
            "Engineering=%@ \n"
            "Art=%@ \n",
            [self answerByType:(AGStudentSubjectTypeBiology)], //установлен бит в маске или нет?маску умнажаем на значение (бит)
            [self answerByType:(AGStudentSubjectTypeMath)],
            [self answerByType:(AGStudentSubjectTypeDeveloping)],
            [self answerByType:(AGStudentSubjectTypePhysics)],
            [self answerByType:(AGStudentSubjectTypePhycology)],
            [self answerByType:(AGStudentSubjectTypePhysics)],
            [self answerByType:(AGStudentSubjectTypeArt)]];
    
}

@end
