//
//  AGStudent.m
//  HomeWork Lesson 15 (Bitwise operations)
//
//  Created by Anton Gorlov on 18.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent

//ученик 3й пукт
-(NSString*) answerByType:(AGStudentSubjectType) type {
    return self.subjectType & type ? @"Yes": @"No";
    
}
-(NSString*) description {
return [NSString stringWithFormat:@"Student name:%@ studies:"
                                  "Art = %@ "
                                  "Biology = %@ "
                                  "Economy = %@ "
                                  "English = %@ "
                                  "Football = %@ "
                                  "Geometria = %@ "
                                  "Math = %@ "
                                  "Physics = %@ "
                                  "Programmer = %@",
                                  self.name,
                                  [self answerByType:AGStudentSubjectTypeArt],
                                  [self answerByType:AGStudentSubjectTypeBiology],
                                  [self answerByType:AGStudentSubjectTypeEconomy],
                                  [self answerByType:AGStudentSubjectTypeEnglish],
                                  [self answerByType:AGStudentSubjectTypeFootball],
                                  [self answerByType:AGStudentSubjectTypeGeometria],
                                  [self answerByType:AGStudentSubjectTypeMath],
                                  [self answerByType:AGStudentSubjectTypePhysics],
                                  [self answerByType:AGStudentSubjectTypeProgrammer]
                                  ];
    
 
}

@end
