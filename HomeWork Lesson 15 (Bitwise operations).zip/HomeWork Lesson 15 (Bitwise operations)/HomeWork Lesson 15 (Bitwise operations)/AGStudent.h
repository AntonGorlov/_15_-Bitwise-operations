//
//  AGStudent.h
//  HomeWork Lesson 15 (Bitwise operations)
//
//  Created by Anton Gorlov on 18.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

// вместо всей этой кучи (BOOL значений) сделаем 1 @property!!
typedef enum {
    AGStudentSubjectTypeMath      =1<<0,
    AGStudentSubjectTypeBiology   =1<<1,
    AGStudentSubjectTypeFootball  =1<<2,
    AGStudentSubjectTypePhysics   =1<<3,
    AGStudentSubjectTypeEnglish   =1<<4,
    AGStudentSubjectTypeArt       =1<<5,
    AGStudentSubjectTypeGeometria =1<<6,
    AGStudentSubjectTypeEconomy   =1<<7,
    AGStudentSubjectTypeProgrammer=1<<8
    
}AGStudentSubjectType;

@interface AGStudent : NSObject

@property (strong,nonatomic) NSString* name;
@property (assign,nonatomic) AGStudentSubjectType subjectType;



/*
@property (assign,nonatomic) BOOL studiesMath;
@property (assign,nonatomic) BOOL studiesBiology;
@property (assign,nonatomic) BOOL studiesFootball;
@property (assign,nonatomic) BOOL studiesPhisics;
@property (assign,nonatomic) BOOL studiesEnglish;
@property (assign,nonatomic) BOOL studiesArt;
@property (assign,nonatomic) BOOL studiesGeometria;
@property (assign,nonatomic) BOOL studiesEconomy;
*/
@end
