//
//  AppDelegate.m
//  HomeWork Lesson 15 (Bitwise operations)
//
//  Created by Anton Gorlov on 18.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGStudent.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
/*
 Ученик.
 
 1. Повторите мой код и создайте класс студент с соответствующим набором предметов
 2. В цикле создайте 10 студентов и добавьте их в массив. Используйте мутабл массив
 3. У каждого рандомно установите предметы
 http://vk.com/topic-58860049_29137723

*/
/*
  #pragma mark -Pupil Level
    NSMutableArray* studentsDorm = [[NSMutableArray alloc]init];
    studentsDorm=[NSMutableArray arrayWithObjects:
                   @"Anton",
                   @"Viktoria",
                   @"Alina",
                   @"Lena",
                   @"Natalia",
                   @"Olga",
                   @"Oksana",
                   @"Irina",
                   @"Anastasia",
                   @"Katja",
                   nil];


    for (NSInteger i = 0; i<10; i++) {
        AGStudent* student = [[AGStudent alloc]init];
        
        void(^studentBlock)(AGStudentSubjectType) = ^(AGStudentSubjectType type){
            
            BOOL result = arc4random()%2;
            if (result) {
                student.subjectType = student.subjectType | type;
            }
        };
        
        studentBlock(AGStudentSubjectTypeArt);
        studentBlock(AGStudentSubjectTypeBiology);
        studentBlock(AGStudentSubjectTypeEconomy);
        studentBlock(AGStudentSubjectTypeEnglish);
        studentBlock(AGStudentSubjectTypeFootball);
        studentBlock(AGStudentSubjectTypeGeometria);
        studentBlock(AGStudentSubjectTypeMath);
        studentBlock(AGStudentSubjectTypePhysics);
        studentBlock(AGStudentSubjectTypeProgrammer);
        
       // NSLog(@"%@", student);
        [studentsDorm addObject:student];
        student.name=[studentsDorm objectAtIndex:i];
    }
    
   // NSLog(@" %@",studentsDorm);
*/
   
    /*
     Студент
     
     4. В новом цикле пройдитесь по студентам и разделите их уже на два массива - технари и гуманитарии.
     5. Также посчитайте количество тех кто учит программирование
     
     и Мастер.
     
     6. Если студенты выбрали биологию, то отмените ее у них и выведите сообщение в лог, предмет отменен
     7. Тут придется разобраться как сбросить бит, включите логику :) "~" (чтобы сбросить бит в маске необхожимо:1) Инвертировать нужный бит (там где "0" будет "1") 2)И умножить на маску)
     */

#pragma mark -Student Level
     // решение "Студента" и "Мастера" через Блоки
    
    NSMutableArray* studentsDorm = [[NSMutableArray alloc]init];
    NSMutableArray*studentsNames=[[NSMutableArray alloc]init];
    studentsNames=[NSMutableArray arrayWithObjects:
                  @"Anton",
                  @"Viktoria",
                  @"Alina",
                  @"Lena",
                  @"Natalia",
                  @"Olga",
                  @"Oksana",
                  @"Irina",
                  @"Anastasia",
                  @"Katja",
                  nil];
    
    
    for (NSInteger i = 0; i<studentsNames.count; i++) {
        AGStudent* student = [[AGStudent alloc]init];
        
        void(^studentBlock)(AGStudentSubjectType) = ^(AGStudentSubjectType type){
            
            BOOL result = arc4random()%2;
            if (result) {
                student.subjectType = student.subjectType | type;
            }
        };
        studentBlock(AGStudentSubjectTypeArt);
        studentBlock(AGStudentSubjectTypeBiology);
        studentBlock(AGStudentSubjectTypeEconomy);
        studentBlock(AGStudentSubjectTypeEnglish);
        studentBlock(AGStudentSubjectTypeFootball);
        studentBlock(AGStudentSubjectTypeGeometria);
        studentBlock(AGStudentSubjectTypeMath);
        studentBlock(AGStudentSubjectTypePhysics);
        studentBlock(AGStudentSubjectTypeProgrammer);

        // NSLog(@"%@", student);
       // student.name=[studentsNames objectAtIndex:i];
        [studentsDorm addObject:student];
        
    }
    
    // NSLog(@" %@",studentsDorm);
    
   
    

    NSMutableArray* humanitiesScience = [[NSMutableArray alloc]init];
    NSMutableArray* engineeringScience = [[NSMutableArray alloc]init];
    
    __block NSInteger programmerCount = 0;
    __block NSInteger biologyCount = 0;
   
    
    for (AGStudent* student in studentsDorm) {
        
        __block NSInteger humanitiesCount = 0;
        __block NSInteger engineeringCount = 0;
        //установим маску
        AGStudentSubjectType myBitMask= AGStudentSubjectTypeArt
                                        |AGStudentSubjectTypeBiology|AGStudentSubjectTypeEconomy
                                        |AGStudentSubjectTypeEnglish|AGStudentSubjectTypeFootball;
        AGStudentSubjectType humanitiesSubjectType = student.subjectType & myBitMask;
        AGStudentSubjectType technicalSubjectType = student.subjectType & ~myBitMask;//[20.11.15, 12:52:34] Jenia: этот знак это  “нет” Jenia: не помню точно что в проекте он делает, скорей всего убирает этот предмет из списка
    
      
        
        void(^humanitiesBlock)(AGStudentSubjectType)=^(AGStudentSubjectType type){
            NSInteger intMask=1;
            for (NSInteger i=0; i<8; i++) {
                if (type & intMask) {
                    humanitiesCount++;
                }
                intMask =intMask<<1;
            }
            if (type & AGStudentSubjectTypeBiology) {
                student.subjectType =student.subjectType & ~AGStudentSubjectTypeBiology;//инвертируем бит,который нужно обнулить ~
                NSLog(@"biology canceled");
                biologyCount++;
            }
        };
        void(^engineeringBlock)(AGStudentSubjectType)=^(AGStudentSubjectType type){
        
            NSInteger intMask=1;
            for (NSInteger i=0; i<8; i++) {
                if (type & intMask) {
                    engineeringCount++;
                }
                intMask=intMask<<1;
            }
            if (type & AGStudentSubjectTypeProgrammer) {
                programmerCount++;
            }
        };
        
       
            
        humanitiesBlock(humanitiesSubjectType);
        engineeringBlock(technicalSubjectType);
        NSLog(@"humanitiesCount=%ld, engineeringCount%ld",humanitiesCount,engineeringCount);
 
            if (humanitiesCount > engineeringCount) {
            NSLog(@"Гуманитариев больше \n\n");
            [humanitiesScience addObject:student];
        }else if (humanitiesCount == engineeringCount){
            NSLog(@"Студентов поровну \n\n");
            [engineeringScience addObject:student];
            [humanitiesScience addObject:student];
        }else {
            NSLog(@"Технарей больше \n\n");
            [engineeringScience addObject:student];
        }
    
    
    
    }
    
    
    NSLog(@"Технарей - %ld, Гуманитариев - %ld, из них programmer:%ld, biology:%ld",[engineeringScience count], [humanitiesScience count],programmerCount, biologyCount);
    
 /*
  Супермен.
  8. Сгенерируйте случайный интежер в диапазоне от 0 до максимума.
  9. Используя цикл и битовые операции (и возможно NSMutableString) выведите это число на экран в двоичном виде
 */
        
    NSInteger intBith = abs(arc4random());
    
    NSInteger intMask = 1;
    
    NSMutableString* stringBith = [[NSMutableString alloc]init];
    
    for (int inFor = 0; inFor < 32; inFor++) {
        
        if (inFor == 8 || inFor == 16 || inFor == 24) {
            
            [stringBith insertString:@" " atIndex:0];
            
        }
        
        if (intBith & intMask) {
            
            [stringBith insertString:@"1" atIndex:0];
            
        }else{
            
            [stringBith insertString:@"0" atIndex:0];
            
        }
        
        intMask = intMask <<1;
        
    }
    
    NSLog(@"%ld = %@", intBith,stringBith);


    
    
    
    
    // Override point for customization after application launch.
    return YES;
}



- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
